import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class Customer extends JPanel {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private DefaultTableModel tableModel;
    private JTable customerTable;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField emailField;
    private JTextField phoneField;
    private List<CustomerData> customers;

    public Customer(CardLayout cardLayout, JPanel mainPanel) {
        this.cardLayout = cardLayout;
        this.mainPanel = mainPanel;
        this.customers = new ArrayList<>();
        setLayout(new BorderLayout());
        setBackground(Color.DARK_GRAY);

        // Add header
        add(createHeaderPanel("Lancaster Music Hall"), BorderLayout.NORTH);

        // Content panel
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(Color.DARK_GRAY);

        // Title label
        JLabel titleLabel = new JLabel("Customers:", JLabel.LEFT);
        titleLabel.setFont(new Font("Verdana", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        contentPanel.add(titleLabel, BorderLayout.NORTH);

        // Table for customer data
        String[] columnNames = {"First Name", "Last Name", "Email", "Phone number"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        customerTable = new JTable(tableModel);
        customerTable.setFont(new Font("Verdana", Font.PLAIN, 14));
        customerTable.setRowHeight(30);
        customerTable.getTableHeader().setFont(new Font("Verdana", Font.BOLD, 14));
        customerTable.getTableHeader().setBackground(Color.LIGHT_GRAY);
        customerTable.getTableHeader().setForeground(Color.BLACK);
        customerTable.setGridColor(Color.LIGHT_GRAY);
        customerTable.setShowGrid(true);
        customerTable.getTableHeader().setReorderingAllowed(false);

        // Enable sorting
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        customerTable.setRowSorter(sorter);

        JScrollPane scrollPane = new JScrollPane(customerTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Input panel
        JPanel inputPanel = new JPanel(new GridLayout(2, 4, 10, 10));
        inputPanel.setBackground(Color.DARK_GRAY);
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setForeground(Color.WHITE);
        firstNameLabel.setFont(new Font("Verdana", Font.PLAIN, 14));
        firstNameField = new JTextField();
        firstNameField.setFont(new Font("Verdana", Font.PLAIN, 14));
        firstNameField.setPreferredSize(new Dimension(200, 30));

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setForeground(Color.WHITE);
        lastNameLabel.setFont(new Font("Verdana", Font.PLAIN, 14));
        lastNameField = new JTextField();
        lastNameField.setFont(new Font("Verdana", Font.PLAIN, 14));
        lastNameField.setPreferredSize(new Dimension(200, 30));

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setForeground(Color.WHITE);
        emailLabel.setFont(new Font("Verdana", Font.PLAIN, 14));
        emailField = new JTextField();
        emailField.setFont(new Font("Verdana", Font.PLAIN, 14));
        emailField.setPreferredSize(new Dimension(200, 30));

        JLabel phoneLabel = new JLabel("Number:");
        phoneLabel.setForeground(Color.WHITE);
        phoneLabel.setFont(new Font("Verdana", Font.PLAIN, 14));
        phoneField = new JTextField();
        phoneField.setFont(new Font("Verdana", Font.PLAIN, 14));
        phoneField.setPreferredSize(new Dimension(200, 30));

        inputPanel.add(firstNameLabel);
        inputPanel.add(firstNameField);
        inputPanel.add(lastNameLabel);
        inputPanel.add(lastNameField);
        inputPanel.add(emailLabel);
        inputPanel.add(emailField);
        inputPanel.add(phoneLabel);
        inputPanel.add(phoneField);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(Color.DARK_GRAY);

        JButton saveButton = new JButton("Save");
        saveButton.setFont(new Font("Verdana", Font.PLAIN, 14));
        saveButton.setPreferredSize(new Dimension(100, 40));
        addHoverEffect(saveButton);
        saveButton.addActionListener(e -> saveCustomer());
        buttonPanel.add(saveButton);

        JButton searchButton = new JButton("Search");
        searchButton.setFont(new Font("Verdana", Font.PLAIN, 14));
        searchButton.setPreferredSize(new Dimension(100, 40));
        addHoverEffect(searchButton);
        searchButton.addActionListener(e -> searchCustomer());
        buttonPanel.add(searchButton);

        JButton deleteButton = new JButton("Delete");
        deleteButton.setFont(new Font("Verdana", Font.PLAIN, 14));
        deleteButton.setPreferredSize(new Dimension(100, 40));
        addHoverEffect(deleteButton);
        deleteButton.addActionListener(e -> deleteCustomer());
        buttonPanel.add(deleteButton);

        JButton clearButton = new JButton("Clear");
        clearButton.setFont(new Font("Verdana", Font.PLAIN, 14));
        clearButton.setPreferredSize(new Dimension(100, 40));
        addHoverEffect(clearButton);
        clearButton.addActionListener(e -> clearFields());
        buttonPanel.add(clearButton);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setFont(new Font("Verdana", Font.PLAIN, 14));
        cancelButton.setPreferredSize(new Dimension(100, 40));
        addHoverEffect(cancelButton);
        cancelButton.addActionListener(e -> cardLayout.show(mainPanel, "MainMenu"));
        buttonPanel.add(cancelButton);

        // Combine input and button panels into bottom panel
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(Color.DARK_GRAY);
        bottomPanel.add(inputPanel, BorderLayout.NORTH);
        bottomPanel.add(buttonPanel, BorderLayout.CENTER);

        // Add components to content panel
        contentPanel.add(bottomPanel, BorderLayout.SOUTH);

        // Add content panel to this Customer panel
        add(contentPanel, BorderLayout.CENTER);
        add(createFooterPanel(), BorderLayout.SOUTH);

        // Initialize with some dummy data
        initializeCustomers();
    }

    private void initializeCustomers() {
        // Add some dummy customers
        customers.add(new CustomerData("John", "Doe", "john.doe@email.com", "12345678910"));
        customers.add(new CustomerData("Jane", "Doe", "jane.doe@email.com", "12345678910"));
        customers.add(new CustomerData("Bob", "Jones", "bob.jones@email.com", "12345678910"));
        customers.add(new CustomerData("Andy", "Davidson", "andy.davidson@email.com", "12345678910"));

        // Populate the table
        updateTable();
    }

    private void updateTable() {
        // Clear the table
        tableModel.setRowCount(0);
        // Populate the table with all customers
        for (CustomerData customer : customers) {
            tableModel.addRow(new Object[]{
                    customer.getFirstName(),
                    customer.getLastName(),
                    customer.getEmail(),
                    customer.getPhone()
            });
        }
    }

    private void saveCustomer() {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();

        // Validate inputs
        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate first name and last name (letters, spaces, hyphens only)
        String nameRegex = "^[A-Za-z\\s-]+$";
        if (!Pattern.matches(nameRegex, firstName)) {
            JOptionPane.showMessageDialog(this, "First name must contain only letters, spaces, or hyphens!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!Pattern.matches(nameRegex, lastName)) {
            JOptionPane.showMessageDialog(this, "Last name must contain only letters, spaces, or hyphens!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate email format
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        if (!Pattern.matches(emailRegex, email)) {
            JOptionPane.showMessageDialog(this, "Invalid email format!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate phone number (10-11 digits)
        String phoneRegex = "\\d{10,11}";
        if (!Pattern.matches(phoneRegex, phone)) {
            JOptionPane.showMessageDialog(this, "Phone number must be 10-11 digits!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Check if customer already exists (based on email)
        boolean customerExists = customers.stream()
                .anyMatch(c -> c.getEmail().equalsIgnoreCase(email));
        if (customerExists) {
            JOptionPane.showMessageDialog(this, "A customer with this email already exists!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Add new customer
        CustomerData newCustomer = new CustomerData(firstName, lastName, email, phone);
        customers.add(newCustomer);
        updateTable();
        clearFields();
        JOptionPane.showMessageDialog(this, "New customer saved successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void searchCustomer() {
        String firstName = firstNameField.getText().trim().toLowerCase();
        String lastName = lastNameField.getText().trim().toLowerCase();
        String email = emailField.getText().trim().toLowerCase();
        String phone = phoneField.getText().trim();

        // Check if all fields are empty
        if (firstName.isEmpty() && lastName.isEmpty() && email.isEmpty() && phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in at least one field to search!", "Error", JOptionPane.ERROR_MESSAGE);
            updateTable(); // Reset the table to show all customers
            return;
        }

        // Clear the table
        tableModel.setRowCount(0);

        // Filter customers based on input
        boolean found = false;
        for (CustomerData customer : customers) {
            boolean matches = true;
            if (!firstName.isEmpty() && !customer.getFirstName().toLowerCase().contains(firstName)) {
                matches = false;
            }
            if (!lastName.isEmpty() && !customer.getLastName().toLowerCase().contains(lastName)) {
                matches = false;
            }
            if (!email.isEmpty() && !customer.getEmail().toLowerCase().contains(email)) {
                matches = false;
            }
            if (!phone.isEmpty() && !customer.getPhone().contains(phone)) {
                matches = false;
            }
            if (matches) {
                tableModel.addRow(new Object[]{
                        customer.getFirstName(),
                        customer.getLastName(),
                        customer.getEmail(),
                        customer.getPhone()
                });
                found = true;
            }
        }

        if (!found) {
            JOptionPane.showMessageDialog(this, "Customer not found", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void deleteCustomer() {
        int selectedRow = customerTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a customer to delete!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Get the email of the selected customer (email is unique)
        String email = (String) tableModel.getValueAt(selectedRow, 2);

        // Remove from the customers list
        customers.removeIf(c -> c.getEmail().equals(email));

        // Update the table
        updateTable();
        JOptionPane.showMessageDialog(this, "Customer deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearFields() {
        firstNameField.setText("");
        lastNameField.setText("");
        emailField.setText("");
        phoneField.setText("");
        // Reset the table to show all customers
        updateTable();
    }

    // Hover effect method
    private void addHoverEffect(JButton button) {
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(true);
        button.setBackground(new Color(60, 63, 65));
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(0, 255, 170));
                button.setForeground(Color.BLACK);
                button.setBorder(BorderFactory.createLineBorder(new Color(0, 255, 170), 2));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(60, 63, 65));
                button.setForeground(Color.WHITE);
                button.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            }
        });
    }

    // Header panel
    private JPanel createHeaderPanel(String title) {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(0, 255, 170));
        headerPanel.setPreferredSize(new Dimension(0, 55));
        JLabel headerLabel = new JLabel(title, JLabel.CENTER);
        headerLabel.setFont(new Font("Verdana", Font.BOLD, 24));
        headerLabel.setForeground(Color.BLACK);
        headerPanel.add(headerLabel, BorderLayout.CENTER);
        return headerPanel;
    }

    // Footer panel
    private JPanel createFooterPanel() {
        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setBackground(new Color(0, 255, 170));
        footerPanel.setPreferredSize(new Dimension(0, 30));
        JLabel footerLabel = new JLabel("BoxOffice Team");
        footerLabel.setFont(new Font("Verdana", Font.BOLD, 14));
        footerLabel.setForeground(Color.BLACK);
        footerLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        footerPanel.add(footerLabel, BorderLayout.WEST);
        JButton signOutButton = new JButton("Sign out");
        signOutButton.setFont(new Font("Verdana", Font.PLAIN, 12));
        signOutButton.setForeground(Color.BLACK);
        signOutButton.setBackground(new Color(0, 255, 170));
        signOutButton.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        signOutButton.setFocusPainted(false);
        signOutButton.addActionListener(e -> cardLayout.show(mainPanel, "Login"));
        footerPanel.add(signOutButton, BorderLayout.EAST);
        return footerPanel;
    }

    // Inner class to store customer data
    private static class CustomerData {
        private String firstName;
        private String lastName;
        private String email;
        private String phone;

        public CustomerData(String firstName, String lastName, String email, String phone) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.phone = phone;
        }

        public String getFirstName() { return firstName; }
        public String getLastName() { return lastName; }
        public String getEmail() { return email; }
        public String getPhone() { return phone; }
    }
}